package com.example.fuzzy;
public enum FuzzyValue {NL, NM, ZR, PM, PL;}
